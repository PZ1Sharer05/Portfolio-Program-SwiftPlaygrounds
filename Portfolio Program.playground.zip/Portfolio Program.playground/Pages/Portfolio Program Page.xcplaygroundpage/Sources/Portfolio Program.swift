
import UIKit
import PlaygroundSupport

let frame = CGRect(x: 0, y: 0, width: 375, height: 667)

public class Portfolio : UIViewController {
    
    
    public var profileName:String!
    public var profileColorTheme:String!
    public var profilePicture:String!
    public var desciptionText:String!
    public var favoritePicture1:String!
    public var favoritePicture2:String!
    public var role:String!
    public var age:String!
    public var name:String!
    
    
    override public func loadView() {
        let view = UIView()
        let label = UILabel()
        let descriptionLabel = UILabel()
        let nameLabel = UILabel()
        let roleLabel = UILabel()
        let ageLabel = UILabel()
        let textView = UITextView()
        
        //: Just prefer to try to just touch the code here. The rest are already handled
        
        
        
        
        nameLabel.text = "Name: " + name
        nameLabel.frame = CGRect(x: 16, y: 191, width: 183, height: 21)
        view.addSubview(nameLabel)
        ageLabel.text = "Age: " + age
        ageLabel.frame = CGRect(x: 16, y: 216, width: 183, height: 21)
        view.addSubview(ageLabel)
        roleLabel.text = "Role: " + role
        roleLabel.frame = CGRect(x: 16, y: 239, width: 283, height: 21)
        view.addSubview(roleLabel)
        
        if profileColorTheme == "white" {
            view.backgroundColor = UIColor.white
            label.textColor = UIColor.black
            descriptionLabel.textColor = UIColor.black
            nameLabel.textColor = UIColor.black
            ageLabel.textColor = UIColor.black
            roleLabel.textColor = UIColor.black
            textView.backgroundColor = UIColor.white
            textView.textColor = UIColor.black
        } else if profileColorTheme == "black" {
            view.backgroundColor = UIColor.black
            label.textColor = UIColor.white
            descriptionLabel.textColor = UIColor.white
            nameLabel.textColor = UIColor.white
            ageLabel.textColor = UIColor.white
            roleLabel.textColor = UIColor.white
            textView.backgroundColor = UIColor.black
            textView.textColor = UIColor.white
        }
        
        label.frame = CGRect(x: 166, y: 28, width: 193, height: 128)
        label.text = profileName
        label.font = label.font.withSize(40)
        
        
        
        view.addSubview(label)
        self.view = view
        
        descriptionLabel.frame = CGRect(x: 16, y: 271, width: 243, height: 49)
        descriptionLabel.font = descriptionLabel.font.withSize(50.0)
        descriptionLabel.text = "Description"
        view.addSubview(descriptionLabel)
        
        textView.frame = CGRect(x: 16, y: 321, width: 343, height: 128)
        textView.text = desciptionText
        textView.isEditable = false
        textView.isSelectable = false
        view.addSubview(textView)
        let profileImage = UIImage(named: profilePicture)
        let profileImageView = UIImageView(image: profileImage)
        profileImageView.frame = CGRect(x: 16, y: 28, width: 128, height: 128)
        profileImageView.contentMode = .scaleAspectFit
        view.addSubview(profileImageView)
        
        let favPicturesLabel = UILabel()
        favPicturesLabel.frame = CGRect(x: 16, y: 456, width: 171, height: 21)
        favPicturesLabel.text = "Favorite Pictures"
        view.addSubview(favPicturesLabel)
        let favPictures1 = UIImageView(image: UIImage(named: favoritePicture1))
        favPictures1.frame = CGRect(x: 16, y: 487, width: 171, height: 171)
        
        view.addSubview(favPictures1)
        
        let favPictures2 = UIImageView(image: UIImage(named: favoritePicture2))
        favPictures2.frame = CGRect(x: 195, y: 487, width: 171, height: 171)
        view.addSubview(favPictures2)
        
        
        
        
     
    }



    
}



