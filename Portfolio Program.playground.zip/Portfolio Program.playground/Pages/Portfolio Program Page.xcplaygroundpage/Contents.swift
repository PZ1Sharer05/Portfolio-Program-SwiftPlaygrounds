import UIKit
import PlaygroundSupport

let portfolio = Portfolio()


PlaygroundPage.current.liveView = portfolio
