//: [Previous](@previous)
/*:
 # Concept Of Programmatic UI
 ### What is programmatic UI
 Programmatic UI is to make the user interface body of the view, but with swift UIKit auto generated classes. It is much more of a time-wasting experience, but also a very important skill to master. The way to implement one is easy. In the next page, you will see and also try the portfolio program. If you want to learn more about mastering the skills, watch my videos in CS Club. You will learn some basic playground concepts. I teach you from beginner to advanced too.
 */
//: [Next](@next)
